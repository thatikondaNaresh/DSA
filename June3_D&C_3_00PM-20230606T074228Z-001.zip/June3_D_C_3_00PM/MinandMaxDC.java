import java.util.*;

public class MinandMaxDC {
    static class Pair{
        int min;
        int max;
    }
    // function definition
    public static Pair findMinandMax(int[] arr, int i, int j){
        Pair minmax = new Pair();
        Pair minmaxLeft = new Pair();
        Pair minmaxRight = new Pair();

        //1. Small Problem - c
        // if the number of elements is equal to 1
        if(i == j){
            minmax.min = arr[i];
            minmax.max = arr[i];
            return minmax;
        }

        // if the number of elements is equal to 2
        else if(i == j-1){
            if(arr[i] < arr[j]){
                minmax.min = arr[i];
                minmax.max = arr[j];
            }
            else{
                minmax.min = arr[j];
                minmax.max = arr[i];
            }
            return minmax;
        }

        // Big Problem
        else{
            // 1. Divide 
            int mid = i + (j-i)/2; // c
            // 2. Conquer
            // left subtree
            minmaxLeft = findMinandMax(arr, i, mid); // T(n/2)
            // right subtree
            minmaxRight = findMinandMax(arr, mid+1, j); // T(n/2)
            // 3. Combine - c
            // to get the final minima
            if(minmaxLeft.min < minmaxRight.min){
                minmax.min = minmaxLeft.min;
            }
            else{
                minmax.min = minmaxRight.min;
            }

            // to get the final maxima
            if(minmaxLeft.max < minmaxRight.max){
                minmax.max = minmaxRight.max;
            }
            else{
                minmax.max = minmaxLeft.max;
            }
            return minmax;

        }
    }
    public static void main(String[] args){
        int[] arr = {20, 50, 10, 15, 25, 55};
        int n = arr.length;
        
        // function calling
        Pair minmax = findMinandMax(arr, 0, n-1);

        System.out.println("The minimum value in the given array is:"+minmax.min);
        System.out.println("The maximum value in the given array is:"+minmax.max);
    }
    
}
