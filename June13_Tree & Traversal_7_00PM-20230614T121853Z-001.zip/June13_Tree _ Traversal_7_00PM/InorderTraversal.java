class Node{
    int data;
    Node left, right;

    public Node(int data){
        this.data = data;
        left = right = null;
    }
}

class InorderTraversal {
    Node root;
    InorderTraversal(){
        root = null;
    }
    

    // function definition of inorder traversal of the tree
    void inorderTraversal(Node node){
        if(node == null){
            return;
        }

        //1. traverse the left subtree
        // recursion 
        
        inorderTraversal(node.left);
        //2. print the data 
        System.out.print(node.data + " ");
        //3. traverse the right subtree
        inorderTraversal(node.right);
    }


    public static void main(String[] args) {
        InorderTraversal tree = new InorderTraversal();
        tree.root = new Node(1);
        tree.root.left = new Node(2);
        tree.root.left.left = new Node(4);
        tree.root.right = new Node(3);
        tree.root.right.left = new Node(5);
        tree.root.right.right = new Node(6);
        tree.root.right.left.left = new Node(7);
        tree.root.right.left.right = new Node(8);

        System.out.println("Inorder traversal of a given tree is:");
        tree.inorderTraversal(tree.root);
        System.out.println(" ");
    }
}
